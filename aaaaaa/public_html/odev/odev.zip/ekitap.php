<?php
include 'includes/header.php';
?>
    <div class="container">
  <div class="row">
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/kurkmantolu.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Kürk Mantolu Madonna</h5>
    <p class="card-text">Sabahattin Ali</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/donusum.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Dönüşüm</h5>
    <p class="card-text">Franz Kafka</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/cal%C4%B1kusu.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Çalıkuşu</h5>
    <p class="card-text">Reşat Nuri Güntekin</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/korku.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Korku</h5>
    <p class="card-text">Stefan Zweig</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/kucukprens.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Küçük Prens</h5>
    <p class="card-text">Antoine de Saint-Exupéry</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/satranc.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Satranç</h5>
    <p class="card-text">Stefan Zweig</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/ucurtma.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Uçurtma Avcısı</h5>
    <p class="card-text">Halit Hüseyni</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 15rem;">
  <img src="images/tutunamayanlar.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Tutunamayanlar</h5>
    <p class="card-text">Oğuz Atay</p>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
  </div>
</div></div>
  </div>
        
<?php
include 'includes/footer.php';
?>