<?php

$bad =$_POST['bagis_ad'];
$bsoyad =$_POST['bagis_soyad'];
$btel =$_POST['bagis_tel'];
$badres =$_POST['bagis_adres'];
$bkitap =$_POST['bagis_kitap'];
$bmesaj =$_POST['bagis_mesaj'];

include_once 'lib/db.php';

$query = $db->prepare('INSERT INTO bagislar (bagis_ad,bagis_soyad,bagis_tel,bagis_adres,bagis_kitap,bagis_mesaj) VALUES (?,?,?,?,?,?)');
$query->execute(array($bad,$bsoyad,$btel,$badres,$bkitap,$bmesaj));
$db=null;


$db=null;
header('location:bagis.php');

?>