    <footer class="section footer-classic context-dark bg-image" style="background: #2d3246;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.php"><strong>Anasayfa</strong></a>
                <p>Aydınlık bir geleğin varlığı kitap okumaktan geçer.</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2019</span><span> </span><span>LibrarySystem32</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>İletişim</h5>
              <dl class="contact-list">
                <dt>Adres:</dt>
                <dd>Bilgi Merkezi 32260 Doğu Yerleşkesi Isparta / Türkiye</dd>
              </dl>
              <dl class="contact-list">
                <dt>e-mail:</dt>
                <dd><a href="mailto:#">kutuphane@sdu.edu.tr</a></dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Linkler</h5>
              <ul class="nav-list">
                <li><a href="#">Anasayfa</a></li>
                <li><a href="#">Hakkımızda</a></li>
                <li><a href="#">İletişim</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row no-gutters social-container">
          <div class="col"><a class="social-inner" href="#"><span><i class="fab fa-facebook"></i> Facebook</span></a></div>
          <div class="col"><a class="social-inner" href="#"><span><i class="fab fa-instagram"></i> instagram</span></a></div>
          <div class="col"><a class="social-inner" href="#"><span><i class="fab fa-twitter"></i> twitter</span></a></div>
          <div class="col"><a class="social-inner" href="#"><span><i class="fab fa-google"></i> google</span></a></div>
        </div>
      </footer>
  </body>
</html>