<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie-edge">
    <title>Kitap Listesi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>


<?php require_once "lib/db.php"; ?>

<?php
/** Verileri çekme Bölümü */
$sozlukler = $db->query("SELECT * from sozlukler",PDO::FETCH_OBJ)->fetchAll();
?>

<?php
include 'includes/header.php';
?>

<div class="container">
  <div class="row">
    <div class="col-8"><h2>   Sözlükler   </h2>
            <table class="table table-hover table-bordered table-striped">
                <thead>
                <th class="text-center">Sözlük</th>
                <th class="text-center">Link</th>
                </thead>
                <tbody>
                <?php foreach ($sozlukler as $product) { ?>
                    <a>
                        <td class="text-center"><strong><?php echo $product->sozluk_ad; ?></strong></td>
                        <td class="text-center"><a href="<?php echo $product->sozluk_link; ?>"><strong><?php echo $product->sozluk_link; ?></strong></td></a>
                    </tr>
                </tbody>
                <?php } ?>
            </table>
  </div>
</div>

    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>

<?php
include 'includes/footer.php';
?>
</html>
