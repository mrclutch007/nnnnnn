<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie-edge">
    <title>Kitap Listesi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>


<?php require_once "lib/db.php"; ?>

<?php
/** Verileri çekme Bölümü */
$kitaplar = $db->query("SELECT * from kitaplar",PDO::FETCH_OBJ)->fetchAll();
?>

<?php
include 'includes/header.php';
?>

<div class="container">
    <h2 class="text-center">Kitap Listesi</h2>
    <hr>
    <div class="row">
        <?php foreach ($kitaplar as $product) { ?>
        <div class="col"><div class="card" style="width: 15rem;">
                <img src="images/<?php echo $product->resim_url; ?>" class="card-img-top" alt="<?php echo $product->kitap_ad; ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $product->kitap_ad; ?></h5>
                    <p class="card-text"><?php echo $product->yazar_ad; ?></p>
                    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
                    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
                    <button kitap_id="<?php echo $product->kitap_id; ?>" class="btn btn-primary addToCartBtn" role="button">
                        <span class="glyphicon glyphicon-shopping-cart"></span> Ödünç Al
                    </button>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
</body>
        
<?php
include 'includes/footer.php';
?>
</html>
