<?php
include 'includes/header.php';
?>
    
        <div class="container">
  <div class="row">
    <div class="col">
      <img src="images/korku.jpg">
    </div>
      <div class="col-md-5 ">
        <h2>   Korku   </h2>
        <table class="mtop">
          <tbody><tr>
            <td><strong>    Yazar:      </strong></td>
            <td>Stefan Zweig
</td>
          </tr>
          <tr>
            <td><strong>   Basımevi:    </strong></td>
            <td>-----------</td>
          </tr>
          <tr>
            <td><strong>Basım yılı: </strong></td>
            <td>------------</td>
          </tr>
          <tr>
            <td><strong>Bilgi: </strong></td>
            <td>------------</td>
          </tr>
              
        </tbody></table>
              <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-up"></i></a>
    <a href="#" class="btn btn-primary"><i class="fas fa-thumbs-down"></i></a>
    <a href="#" class="btn btn-primary">Ödünç Al</a>
            <div class="form-group">
    <label for="exampleFormControlTextarea1"><strong>Yorum Yap</strong></label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                <button type="button" class="btn btn-primary">Yorum Yap</button>
  </div>
</form>
      </div>
  </div>

<?php
include 'includes/footer.php';
?>