<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie-edge">
    <title>Sepetim</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
</head>
<body>

<?php
include 'includes/header.php';
?>
<div class="container">
    <?php if ($toplam_adet > 0) { ?>
        <h2 class="text-center">Sepetinizde <strong class="color-danger"><?php echo $toplam_adet; ?></strong> adet kitap bulunmaktadır.</h2>
        <hr>
        <div class="row">
            <div class="col-md-12 col-md-offset-2">
                <table class="table table-hover table-bordered table-striped">
                    <thead>
                    <th class="text-center">Kitap Resmi</th>
                    <th class="text-center">Kitap Adı</th>
                    <th class="text-center">Yazar Adı</th>
                    <th class="text-center">Basımevi</th>
                    <th class="text-center">Alım Tarihi</th>
                    <th class="text-center">Teslim Tarihi</th>
                    <th class="text-center">Adet</th>
                    <th class="text-center">Sepetten Çıkar</th>
                    </thead>
                    <tbody>
                    <?php foreach ($shopping_products as $product) { ?>


                        <tr>
                            <td class="text-center" width="120">
                                <img src="images/<?php echo $product->resim_url; ?>" alt="" width="50">
                            </td>
                            <td class="text-center"><strong><?php echo $product->kitap_ad; ?></strong></td>
                            <td class="text-center"><strong><?php echo $product->yazar_ad; ?></strong></td>
                            <td class="text-center"><strong>... Basımevi</strong></td>
                            <td class="text-center">
                                <input type="date" id="adres" name="adres" class="form-control">
                            </td>
                            <td class="text-center">
                                <input type="date" id="adres" name="adres" class="form-control">
                            </td>
                            <td class="text-center">
                                <a href="lib/sepet_db.php?p=incCount&kitap_id=<?php echo $product->kitap_id; ?>" class="btn btn-xs btn-success">
                                    <span class="glyphicon glyphicon-plus"></span>
                                </a>
                                <input type="text" class="item-count-input" value="<?php echo $product->count; ?>">
                                <a href="lib/sepet_db.php?p=decCount&kitap_id=<?php echo $product->kitap_id; ?>" class="btn btn-xs btn-danger">
                                    <span class="glyphicon glyphicon-minus"></span>
                                </a>
                            </td>
                            <td class="text-center" width="120">
                                <button kitap_id="<?php echo $product->kitap_id; ?>" class="btn btn-danger btn-sm removeFromCartBtn">
                                    <span class="glyphicon glyphicon-remove"></span>
                                    Sepetten Çıkar
                                </button>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                    <tfoot>
                    <th colspan="4" class="text-center">
                        Toplam kitap : <span class="color-danger"><?php echo $toplam_adet; ?></span>
                    </th>
                    <th colspan="4" class="text-center">
                        <button class="btn btn-success">Sepeti Onayla</button>
                    </th>
                    </tfoot>
                </table>
            </div>
            <?php } else { ?>
                <div class="alert alert-info">
                    <strong>Sepetinizde kitap bulunmamaktadır.Eklemek için <a href="kitap.php">tıklayınız.</a> </strong>
                </div>
            <?php } ?>
</div>

<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
</body>

<?php
include 'includes/footer.php';
?>
</html>
